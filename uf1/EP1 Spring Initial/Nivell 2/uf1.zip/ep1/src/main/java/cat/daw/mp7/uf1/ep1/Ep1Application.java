package cat.daw.mp7.uf1.ep1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ep1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ep1Application.class, args);
	}

}
